﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pr14_3_5_KM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(numericUpDown1.Value);
            string text = $"n = {n}";
            listBox1.Items.Add(text);

            Queue<int> arr = new Queue<int>();

            for (int i = 1; i <= n; i++)
            {
                arr.Enqueue(i);
            }

            int count = (from i in arr select i).Count();
            text = $"Размерность очереди {count}";
            listBox1.Items.Add(text);

            int upQe = arr.Peek();
            text = $"Верхний элемент очереди {upQe}";
            listBox1.Items.Add(text);

            string text1 = "";
            foreach (int i in arr)
            {
                text1 += $"{i} ";
            }
            text = $"Содержимое очереди {text1}";
            listBox1.Items.Add(text);

            arr.Clear();

            count = (from i in arr select i).Count();
            text = $"Размерность очереди {count}";
            listBox1.Items.Add(text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] wrk = File.ReadAllLines("WRK.txt");

            Queue<Worker> workers = new Queue<Worker>();

            foreach (var word in wrk)
            {
                var words = word.Split(' ');

                if (words.Length == 5)
                {
                    Worker newWrk = new Worker();
                    newWrk.SetSurname(words[0]);
                    newWrk.SetName(words[1]);
                    newWrk.SetSname(words[2]);

                    if (int.TryParse(words[3], out int age))
                    {
                        newWrk.SetAge((age));
                    }
                    else
                    {
                        MessageBox.Show("В поле возраста не число");
                        break;
                    }
                    if (double.TryParse(words[4], out double ves))
                    {
                        newWrk.SetVes(ves);
                    }
                    else
                    {
                        MessageBox.Show("В поле веса не число");
                        break;
                    }
                    workers.Enqueue(newWrk);
                }  
                else
                {
                    MessageBox.Show("Не хватает или есть лишние данные в строке");
                    break;
                }
            }

            var youngWrk = workers.OrderBy(p=>p.GetAge() >= 40).ThenBy(p=>p.GetAge()).ToList();

            foreach (var worker in youngWrk)
            {
                listBox2.Items.Add($"{worker.GetSurame()} {worker.GetName()} {worker.GetSname()} {worker.GetAge()} {worker.GetVes()}");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] nss = File.ReadAllLines("ФИО.txt");
            string[] number = File.ReadAllLines("числа.txt");

            Queue<Worker> workers = new Queue<Worker>();

            int i = 0;
            foreach (var word in nss)
            {
                string wrk = word + " " + number[i];
                var words = wrk.Split(' ');

                if (words.Length >= 5)
                {
                    Worker newWrk = new Worker();
                    newWrk.SetSurname(words[0]);
                    newWrk.SetName(words[1]);
                    newWrk.SetSname(words[2]);

                    if (int.TryParse(words[3], out int age))
                    {
                        newWrk.SetAge((age));
                    }
                    else
                    {
                        MessageBox.Show("В поле возраста не число");
                        break;
                    }
                    if (double.TryParse(words[4], out double ves))
                    {
                        newWrk.SetVes(ves);
                    }
                    else
                    {
                        MessageBox.Show("В поле веса не число");
                        break;
                    }
                    workers.Enqueue(newWrk);
                }
                else
                {
                    MessageBox.Show("Не хватает или есть лишние данные в строке");
                    break;
                }
                i++;
            }

            var wrkGroup = workers.GroupBy(wrk => wrk.GetSurame().First()).OrderBy(group => group.Key).SelectMany(group => group.OrderBy(wrk => wrk.GetAge())).ToList();

            foreach (var wrk in wrkGroup)
            {
                listBox3.Items.Add($"{wrk.GetSurame()} {wrk.GetName()} {wrk.GetSname()} {wrk.GetAge()} {wrk.GetVes()}");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr14_3_5_KM
{
    class Worker
    {
        private string name;
        private string surname;
        private string sname;
        private int age;
        private double ves;

        public void SetName(string name)
        {
            this.name = name;
        }
        public string GetName()
        {
            return this.name;
        }
        public void SetSurname(string surname)
        {
            this.surname = surname;
        }
        public string GetSurame()
        {
            return this.surname;
        }
        public void SetSname(string sname)
        {
            this.sname = sname;
        }
        public string GetSname()
        {
            return this.sname;
        }
        public void SetAge(int age)
        {
            this.age = age;
        }
        public int GetAge()
        {
            return this.age;
        }
        public void SetVes(double ves)
        {
            this.ves = ves;
        }
        public double GetVes()
        {
            return this.ves;
        }
    }
}
